﻿function registrationClick() {
    //   window.location.replace("https://www.facebook.com/you.tunel");
    window.open("https://www.facebook.com/you.tunel", 'preview_tab');
    return false;
}

//setup parallax
$(document).ready(function() {
    $('#nav').localScroll(500);
    $('#slide1').parallax("50%", 0.1);
    $('#slide3').parallax("50%", 0.1);
    $('.slide1b').parallax("90.5%", 0.5, true, 650);
    //$('.slide3b').parallax("30%", 0.2,true,2800);
    //$('#david').parallax("93%", 0.5, true, 2000);
});


